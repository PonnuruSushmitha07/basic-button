const button = document.getElementById('colorButton');

// Array of colors to cycle through
const colors = ['#007bff', '#28a745', '#dc3545', '#ffc107', '#17a2b8'];

let colorIndex = 0;

// Change button color when clicked
button.addEventListener('click', () => {
    // Increment the index and wrap it around using modulo
    colorIndex = (colorIndex + 1) % colors.length;
    button.style.backgroundColor = colors[colorIndex];
});
